Put all the Email.txt into test folder to find if email is spam or not
run whole jupyter notebook first then at last there is code section with testing the model where we are checking our results